package factorial;
import static org.junit.Assert.*;

import org.junit.Test;


public class FactorialTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
