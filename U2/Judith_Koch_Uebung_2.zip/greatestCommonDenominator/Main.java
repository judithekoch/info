package greatestCommonDenominator;

public class Main {

		public static void main(String args[]){
			
		GCD gcd = new GCD();
		System.out.println(gcd.gcd(23494,3436));
	}
	
}
