package listStackChainNode;

public class Node<T> {	 //implements List<T>{ warum sollte Node List implementieren???
	private T element;
	private Node<T> next;

	
	public Node(T element,  Node<T> next){
			this.element = element;
			this.next = next;
	}

	
	public T getElement(){ //head()
		return element;
	} 

	public Node<T> getNext(){ //tail()
		return next;
	}
	
	public void setNext(Node<T> next){
		this.next = next;
	}

	public int getLength(){
		return 1 + (next == null ? 0 : next.getLength());
    }
	
    /*public void insert(T value, int position){
    // TODO	
    }
    
    public void remove(int position){
        // TODO    	
    }*/
}

