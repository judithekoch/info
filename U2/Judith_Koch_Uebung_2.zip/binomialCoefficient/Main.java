package binomialCoefficient;

public class Main {

	public static void main(String[] args) {
		BinCoefficient bc = new BinCoefficient();
		System.out.println(bc.factorial(5));
		System.out.println(bc.binCoefficient(9,4));
		System.out.println(bc.binCoefficient(2,4));
	}
	
}
