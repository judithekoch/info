package areas;

public interface Squares extends Rectangles {

}
