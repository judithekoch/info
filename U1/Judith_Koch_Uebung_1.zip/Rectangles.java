package areas;

public interface Rectangles {
	
	public float getArea();

}
