package areas;

public interface AreaModels {

	public void getAreas();
}
